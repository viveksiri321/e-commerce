// ====== Required Modules ======
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const db = require('./db');

const app = express();
const PORT = 3000;

// ====== Middleware ======
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: 'foodiesSecret123',
    resave: false,
    saveUninitialized: true
}));

// ====== Middleware to check if user is logged in ======
function isLoggedIn(req, res, next) {
    if(req.session.userId) next();
    else res.redirect('/login');
}

// ====== Home Page ======
app.get('/', (req, res) => {
    res.render('index', { user: req.session.user });
});

// ====== Register ======
app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    db.query('INSERT INTO users (name,email,password) VALUES (?,?,?)', 
        [name, email, hashedPassword], (err, result) => {
            if(err){
                console.log(err);
                return res.send('Error registering user. Maybe email already exists.');
            }
            res.redirect('/login');
        });
});

// ====== Login ======
app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.query('SELECT * FROM users WHERE email=?', [email], async (err, result) => {
        if(err) return res.send('Database error.');
        if(result.length === 0) return res.send('User not found.');

        const user = result[0];
        if(await bcrypt.compare(password, user.password)){
            req.session.userId = user.id;
            req.session.user = user.name;
            res.redirect('/');
        } else {
            res.send('Incorrect password.');
        }
    });
});

// ====== Logout ======
app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

// ====== Menu Page ======
app.get('/menu', isLoggedIn, (req, res) => {
    db.query('SELECT * FROM menu', (err, result) => {
        if(err) return res.send('Error fetching menu.');
        res.render('menu', { menu: result, user: req.session.user });
    });
});

// ====== Add to Cart ======
app.post('/cart', isLoggedIn, (req, res) => {
    const { menu_id, quantity } = req.body;
    db.query('INSERT INTO cart (user_id, menu_id, quantity) VALUES (?,?,?)',
        [req.session.userId, menu_id, quantity], (err, result) => {
            if(err) return res.send('Error adding to cart.');
            res.redirect('/cart');
        });
});

// ====== Cart Page ======
app.get('/cart', isLoggedIn, (req, res) => {
    db.query(`SELECT c.id, m.name, m.price, c.quantity 
              FROM cart c JOIN menu m ON c.menu_id=m.id 
              WHERE c.user_id=?`, [req.session.userId], (err, result) => {
        if(err) return res.send('Error fetching cart.');
        res.render('cart', { cart: result, user: req.session.user });
    });
});

// ====== Checkout Page ======
app.get('/checkout', isLoggedIn, (req, res) => {
    db.query(`SELECT c.id, m.name, m.price, c.quantity 
              FROM cart c JOIN menu m ON c.menu_id=m.id 
              WHERE c.user_id=?`, [req.session.userId], (err, result) => {
        if(err) return res.send('Error fetching checkout.');
        res.render('checkout', { cart: result, user: req.session.user });
    });
});

// ====== Start Server ======
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
app.use(express.urlencoded({ extended: true }));
app.post('/place-order', (req, res) => {
    const { name, phone, address, payment } = req.body;

    // TEMP: just testing (later we save to DB)
    console.log("Order placed:");
    console.log(name, phone, address, payment);

    // Clear cart after order (optional)
    // db.query("DELETE FROM cart WHERE user_id = ?", [req.session.userId]);

    res.render('order-success', {
        name,
        payment
    });
});
app.use(express.urlencoded({ extended: true }));
