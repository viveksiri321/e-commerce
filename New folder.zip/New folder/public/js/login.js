const loginForm = document.querySelector('form');
if(loginForm){
  loginForm.addEventListener('submit', e => {
    const email = loginForm.querySelector('input[name="email"]').value;
    if(!email.includes('@')){
      e.preventDefault();
      alert('Please enter a valid email!');
    }
  });
}
