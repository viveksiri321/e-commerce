const registerForm = document.querySelector('form');
if(registerForm){
  registerForm.addEventListener('submit', e => {
    const password = registerForm.querySelector('input[name="password"]').value;
    if(password.length < 6){
      e.preventDefault();
      alert('Password must be at least 6 characters long!');
    }
  });
}
