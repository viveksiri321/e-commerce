document.querySelectorAll('form[action="/cart"]').forEach(form => {
  form.addEventListener('submit', e => {
    alert("Item added to cart!");
  });
});
