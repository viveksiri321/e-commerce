const payButton = document.querySelector('button');
if(payButton){
  payButton.addEventListener('click', () => {
    alert('Payment successful! Thank you for your order.');
  });
}
